public class IllegalVehicle extends Exception {

    // Constructor for the class
    public IllegalVehicle (String message) {
        // Throw error message passed through the class call
        super(message);
    }

}

